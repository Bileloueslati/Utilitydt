
import express from "express";
import { userService } from "./modules/user/user.service";

export const app = express();

app.use(express.json());

app.get("/users", async (req, res) => {
  const users = await userService.getUsers();
  res.json(users);
});

app.post("/users", async (req, res) => {
  const user = await userService.createUser(req.body);
  res.json(user);
});
