
import { app } from "./app";
import { prisma } from "./infrastructure/database/prisma";

const PORT = process.env.PORT || 3000;

async function start() {
  try {
    await prisma.$connect();
    console.log("DB connected");

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (err) {
    console.error("Error starting app", err);
  }
}

start();
