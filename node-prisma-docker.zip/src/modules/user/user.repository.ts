
import { prisma } from "../../infrastructure/database/prisma";

export const userRepository = {
  findAll: () => prisma.user.findMany(),
  create: (data: { email: string; name?: string }) =>
    prisma.user.create({ data }),
};
