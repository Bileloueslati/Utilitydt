
import { userRepository } from "./user.repository";

export const userService = {
  getUsers: () => userRepository.findAll(),
  createUser: (data: { email: string; name?: string }) =>
    userRepository.create(data),
};
